<?php
require_once 'main.options.php';
require_once 'install.demo.php';